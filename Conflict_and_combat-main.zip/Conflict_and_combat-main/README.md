## Welcome to the pools of battles!


“conflict and combat” is a mini game project where we derived the basic concept of two character fighting against each other from the very popular and simple Rock-paper-scissors game that is played by two people.
### SEMANTICS BEHIND THE GAME 

The main algorithm includes making a 2-D matrix , converting it into a tupple then using it as conclusive fucntion

```markdown
In our mini-project, we built a Python function that simulates playing a
round of game aka “combat” by generating its own random choice from these
alternatives character warriors we provided and then determining 
the winner using a simple rule.

While a simple Rock-paper-scissor has a set of three rules that logically 
determine who wins a round of  coding up these rules would require  of
if/ elif/ else. We opted for simpler method for determining the winner is to assign
each of the respective choices. 

For example: choice number -7 number:
0 — character 1 
1 — character 2 
2 — character 3 
3 — character 4 
4 — character 5 
5— character 6
6 — character 7

then making a matirix to justify all the relationshtip between these characters.
```


### Project explores various python concepts like :

- Loops and conditons
- Functions
- Tuples
- lists
- Exception Handling
- File Handling


### OUTCOME

During the building process of this project we came across a lot of problems in our code but we overcame those by going through the various topics related to our project. It have been great experience for us to get to know the industry level of programing and know how we can apply those concepts in real world projects

### Support or Contact

Having some quaries? you can reach us through our linkdin profile [Sidhartha Parasramka](https://www.linkedin.com/in/sidhartha-parasramka/) or [Soumya Agrawal](https://www.linkedin.com/in/soumyaagrawal427/) and we’ll help you sort it out.
